#include <stdint.h>
#include <stddef.h>
#include <sstream>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <unordered_set>
#include <vector>
#include <cstdlib>
#include <string>
#include <cstring>
#include <ctime>
#include <cstdio>
#include <stdlib.h>
#include <unistd.h>
using namespace std;

string username, password, tenant_id, tenant_op, tenant_times;

/* Types of operations */
string tenant_int_op;
int tenant_int_modulo;

string tenant_str_op;

/* Delays */
int action_idx = 0;
int last_action_idx;
vector<int> action_times;

// Semirandom var
int semi_rand = 0;

void log_interaction(string type, string value, string username, string tenant_id) {
    ofstream log_file;

    // Clear file data first time
    if (type == "RANDOM_SEED") {
        log_file.open("LOG_" + username + ".txt");
        value = username; 
    }
    else
        log_file.open("LOG_" + username + ".txt", ios_base::app);

    time_t t = time(0);
    
    log_file << t << " " << tenant_id << " " << type << " " << value << endl;
    log_file.close();
}

bool replace(std::string& str, const std::string& from, const std::string& to) {
    size_t start_pos = str.find(from);
    if(start_pos == std::string::npos)
        return false;
    str.replace(start_pos, from.length(), to);
    return true;
}

string exec_cmd_response(string cmd) {
    int random_nr = rand() % 100000;
    string random_str = to_string(random_nr);

    string resp = "response.txt";
    string new_resp = "response_" + random_str + ".txt";
    replace(cmd, resp, new_resp);
    
    cout << "# NEW CMD: " << cmd << endl;

    // Ignore output
    cmd += ">/dev/null 2>&1";

    system(cmd.c_str());
    usleep(1000000);

    ifstream r(new_resp);
    string response; getline(r, response);
    r.close();

    if (remove(new_resp.c_str()) != 0)
        perror("Error deleting file");

    return response;
}

bool login(string username, string password) {

    string cmd = "wget -np -O response.txt localhost:5000/login/" + username + "/" + password;
    string response = exec_cmd_response(cmd);

    if (response != "Okay") {
        cout << "Can't login with: " << username << " " << password 
             << ". Error: " << response << endl;
        exit(-1);
    }

    log_interaction("LOGIN", "-", username, tenant_id);
    return true;
}
bool logout(string username) {
    string cmd = "wget -np -O response.txt localhost:5000/logout/" + username;
    string response = exec_cmd_response(cmd);

    if (response != "Okay") {
        cout << "Can't logout with: " << username  
             << ". Error: " << response << endl;
        exit(-1);
    }

    log_interaction("LOGOUT", "-", username, tenant_id);
    return true;
}
bool tenant_lock(string tenant_id, string username) {
    string cmd = "wget -np -O response.txt localhost:5000/lock/" + tenant_id + "/" + username;
    string response = exec_cmd_response(cmd);

    if (response != "Locked") {
        cout << "Can't lock " << tenant_id << " with: " << username  
             << ". Error: " << response << endl;
        action_idx--;
        // exit(-1);
    }

    return true;
}
bool tenant_unlock(string tenant_id, string username) {
    string cmd = "wget -np -O response.txt localhost:5000/unlock/" + tenant_id + "/" + username;
    string response = exec_cmd_response(cmd);

    if (response != "Unlocked") {
        cout << "Can't unlock " << tenant_id << " with: " << username  
             << ". Error: " << response << endl;
        // exit(-1);
    }

    return true;
}
bool tenant_locked_by_me(string tenant_id, string username) {
    string cmd = "wget -np -O response.txt localhost:5000/locked/" + tenant_id;
    string response = exec_cmd_response(cmd);

    if (response != username) {
        cout << "Resource at " << tenant_id << " is not locked by me: " << username  
             << ". Error: " << response << "Continuing..." << endl;
        return false;
    }

    return true;
}
bool set_string_value(string value, string tenant_id, string username, string diff) {
    if (tenant_locked_by_me(tenant_id, username) == false)
        return false;

    if (value == "") 
        value = "NULLUN";

    string cmd = "wget -np -O response.txt localhost:5000/set/" + value + "/" + tenant_id + "/" + username;
    string response = exec_cmd_response(cmd);

    if (response.substr(0, 5) == "ERROR") {
        cout << "SET STRING Resource at " << tenant_id << " cannot be set by: " 
             << username << ". Error: " << response << "Continuing..." << endl;
        return "ERROR";
    }

    log_interaction("SET_STRING", diff + "###" + value, username, tenant_id);
    return true;
}

string get_string_value(string tenant_id, string username) {
    if (tenant_locked_by_me(tenant_id, username) == false)
        return "ERROR";

    string value = "";

    string cmd = "wget -np -O response.txt localhost:5000/get/" + tenant_id + "/" + username;
    string response = exec_cmd_response(cmd);

    if (response.substr(0, 5) == "ERROR") {
        cout << "GET STR Resource at " << tenant_id << " cannot be retrieved by: " << username  
             << ". Error: " << response << "Continuing..." << endl;
        return "ERROR";
    }

    value = response;

    log_interaction("GET_STRING", value, username, tenant_id);
    return value;
}
bool set_int_value(string value, string tenant_id, string username, string diff) {
    if (tenant_locked_by_me(tenant_id, username) == false)
        return false;

    string cmd = "wget -np -O response.txt localhost:5000/set/" + value + "/" + tenant_id + "/" + username;
    string response = exec_cmd_response(cmd);

    if (response.substr(0, 5) == "ERROR") {
        cout << "SET STRING Resource at " << tenant_id << " cannot be set by: " 
             << username << ". Error: " << response << "Continuing..." << endl;
        return "ERROR";
    }

    log_interaction("SET_INT", diff + "###" + value, username, tenant_id);
    return true;
}
int get_int_value(string tenant_id, string username) {
    if (tenant_locked_by_me(tenant_id, username) == false)
        return -1;

    int value = 0;

    string cmd = "wget -np -O response.txt localhost:5000/get/" + tenant_id + "/" + username;
    string response = exec_cmd_response(cmd);

    if (response.substr(0, 5) == "ERROR") {
        cout << "GET INT Resource at " << tenant_id << " cannot be retrieved by: " << username  
             << ". Error: " << response << "Continuing..." << endl;
        return -1;
    }

    istringstream iss(response);
    iss >> value;

    log_interaction("GET_INT", to_string(value), username, tenant_id);
    return value;
}

bool interact(const uint8_t *Data, size_t DataSize){
    int nr_of_bytes = 4;
    if (DataSize < nr_of_bytes)
        return false;

    /* Login ONCE
    // No more actions needed
    if (action_idx == last_action_idx) {
        logout(username);
        exit(0); // Exit with FUZZ EXIT
        //return false; // Exit normally
    }

    // First time we must log in
    if (action_idx == 0)
        login(username, password);
    */

    if (action_idx == last_action_idx) {
        exit(0); // Exit with FUZZ EXIT
    }


    usleep(action_times[action_idx] * 1000); // microseconds
    action_idx++;

    /* Login each time */
    login(username, password);

    tenant_lock(tenant_id, username);

    if (tenant_op == "int") {
        int value = get_int_value(tenant_id, username);
        if (value == -1)
            goto exit_func;
        if (value == 0 && tenant_int_op == "mul")
            value = 1;

        int diff;
        if (tenant_int_op == "add")
            diff = 0;
        else if (tenant_int_op == "mul")
            diff = 1;

        if (tenant_int_op == "add")
            for (int i = 0; i < nr_of_bytes; i++) {
                value += int(Data[i]);
                diff += int(Data[i]);
            }
        else if (tenant_int_op == "mul")
            for (int i = 0; i < nr_of_bytes; i++) 
                if (int(Data[i]) != 0) {
                    value *= int(Data[i]);
                    diff *= int(Data[i]);
                }
        value %= tenant_int_modulo;

        set_int_value(to_string(value), tenant_id, username, to_string(diff));
    } else if (tenant_op == "str") {
        string value = get_string_value(tenant_id, username);
        if (value == "ERROR")
            goto exit_func;

        string diff = "";
        for (int i = 0; i < nr_of_bytes; i++) {
            int parity = int(Data[i]) % 2;
            int offset = Data[i] % 26;

            if (parity == 0) {
                value += 'A' + offset;
                diff += 'A' + offset;
            } else {
                value += 'a' + offset;
                diff += 'a' + offset;
            }

            /* Don't usually happens
            if ((Data[i] >= 'A' && Data[i] <= 'Z') ||
                (Data[i] >= 'a' && Data[i] <= 'z'))
                value += Data[i];
            */
        }

        if (tenant_str_op == "add_sort") {
            sort(value.begin(), value.end());
        } else if (tenant_str_op == "add_sort_reverse") {
            sort(value.begin(), value.end());
            reverse(value.begin(), value.end());
        } else if (tenant_str_op == "add_set") {
            unordered_set<char> log;
            value.erase(remove_if(value.begin(), value.end(), [&] (char const c) { return !(log.insert(c).second); }), value.end());
            sort(value.begin(), value.end());
        } else if (tenant_str_op == "add_set_reverse") {
            unordered_set<char> log;
            value.erase(remove_if(value.begin(), value.end(), [&] (char const c) { return !(log.insert(c).second); }), value.end());
            sort(value.begin(), value.end());
            reverse(value.begin(), value.end());
        }

        set_string_value(value, tenant_id, username, diff);
    }
    
exit_func:
    tenant_unlock(tenant_id, username);
    /* Logout each time */
    logout(username);

    return true;
}

bool FuzzMe(const uint8_t *Data, size_t DataSize) {
    return DataSize >= 3 &&
        Data[0] == 'F' &&
        Data[1] == 'U' &&
        Data[2] == 'Z' &&
        Data[3] == 'Z';  // :‑<
}

extern "C" int LLVMFuzzerTestOneInput(const uint8_t *Data, size_t Size) {
    //FuzzMe(Data, Size);
    interact(Data, Size);
    return 0;
}

extern "C" int LLVMFuzzerInitialize(int *argc, char ***argv) {
    if (*argc != 6)
        exit(-1);

    username.assign((*argv)[1], strlen((*argv)[1]));
    password.assign((*argv)[2], strlen((*argv)[2]));
    tenant_id.assign((*argv)[3], strlen((*argv)[3]));
    tenant_op.assign((*argv)[4], strlen((*argv)[4]));
    tenant_times.assign((*argv)[5], strlen((*argv)[5]));
    cout << "Initialized:" 
         << "\t username: " << username << " "
         << "\t password: " << password << " "
         << "\t tenant_id: " << tenant_id << " "
         << "\t tenant_op: " << tenant_op << " "
         << "\t tenant_times: " << tenant_times << endl;

    // Modify tenant_op to be either int or str
    // Modifiy tenant_int* or tenant_str* accordingly
    if (tenant_op.substr(0, 3) == "int") {
        if (tenant_op.substr(4, 3) == "add")
            tenant_int_op = "add";
        else if (tenant_op.substr(4, 3) == "mul")
            tenant_int_op = "mul";
        else {
            cout << "Tenant_op must be int_(add|mul)_..." << endl;
            exit(-1);
        }

        istringstream ss(tenant_op.substr(8, tenant_op.size()));
        ss >> tenant_int_modulo;
        cout << "Int operation params: " << tenant_int_op << " " << tenant_int_modulo << endl;
    } else if (tenant_op.substr(0, 3) == "str") {
        tenant_str_op = tenant_op.substr(4, tenant_op.size());
        cout << "String operation params: " << tenant_str_op << endl;
    }
    tenant_op = tenant_op.substr(0, 3);

    // Save operation time to vector
    stringstream timesstream(tenant_times);
    string string_time;
    
    while(getline(timesstream, string_time, '_')) {
        istringstream iss(string_time);
        int time; iss >> time;
        action_times.push_back(time);
        last_action_idx++;

        semi_rand += time;
    }

    cout << "We will interact with the system " << last_action_idx << " times at: " << endl;
    for (int i = 0; i < last_action_idx; i++)
        cout << "\t" << action_times[i] << endl;

    // Set random:
    int random_seed = time(0) + semi_rand;
    srand(random_seed);

    log_interaction("RANDOM_SEED", to_string(random_seed), username, tenant_id);

    // Remove args
    *argc -= 5;

    return 0;
}
